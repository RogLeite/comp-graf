
var minha = null;
if (minha===null) {
	console.log("É nulo");
} else {
	console.log("NÃO nulo");
}